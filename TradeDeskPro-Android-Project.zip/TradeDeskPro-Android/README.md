# Trade Desk Pro – Android Studio project

This is an Android WebView wrapper around the Trade Desk Pro offline HTML app.

## What is included
- Trade Desk Pro HTML app bundled in `app/src/main/assets/index.html`.
- Android launcher activity and offline-capable WebView configuration.
- JavaScript bridge that saves PDF, Excel, CSV and JSON exports to `Downloads/Trade Desk Pro`.
- Android file picker support for restoring a JSON backup.
- Internet permission for optional Google Apps Script / Drive backup.

## Build the APK
This project is source code, not a precompiled APK. Build it on a computer with Android Studio:
1. Install Android Studio and Android SDK Platform 35.
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the `TradeDeskPro-Android` folder.
4. Wait for Gradle sync. Use JDK 17 if prompted.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Find the debug APK at `app/build/outputs/apk/debug/app-debug.apk`.
7. Copy the APK to your Android phone and install it. If Android asks, allow installing unknown apps for the app used to open the APK.

## Important notes
- Local trade data is stored in this app's WebView storage on this device.
- Uninstalling the app or clearing its storage can remove local data. Export JSON backups regularly.
- Google Drive backup needs internet and a correctly deployed Google Apps Script web app. It is optional; local trading records and calculations work offline.
- The APK is not yet compiled or signed for Play Store release. Android Studio's debug APK is for direct testing.
- The app password is an app access barrier, not encryption of the underlying local database.
